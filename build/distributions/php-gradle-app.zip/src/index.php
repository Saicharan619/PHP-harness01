<?php
namespace App;

class Calculator {
    public static function add($a, $b) {
        return $a + $b;
    }
}

